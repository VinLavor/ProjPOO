package br.ufc.poo.petshop.Funcionarios;
public class LucroTotal {
    
}
